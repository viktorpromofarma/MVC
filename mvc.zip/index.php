<?php 

require 'server.php';
<?php 

namespace App\Controller\Pages;
use \App\Utils\View;

class Home {

    static public function getHome(){

        return View::render('home', [
            'user' => 'Ryan Matheus',
        ]);

    }

}
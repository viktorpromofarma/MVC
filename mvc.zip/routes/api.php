<?php 

use \App\Http\Response;
use \App\Controller\Pages;

$obRouter->post('/api/', [
    function(){
        return "API PAGE";
    }
]);
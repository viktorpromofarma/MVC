<?php 



define('DEFAULTTITLE', 'Turma 247');

define('DATABASE', [
    'HOST' => "localhost",
    'USER' => "root",
    'PASS' => "",
    "NAME" => "siteturma"
]);
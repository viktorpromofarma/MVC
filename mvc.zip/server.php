<?php 

define('__WWW__', __DIR__);
define('URLSITE', 'https://'.$_SERVER['HTTP_HOST']);

function debug($var){

    echo("<pre>");
    print_r($var);
    echo "</pre>";

}

require __WWW__.'/tm-config.php';

require __WWW__.'/vendor/autoload.php';

use \App\Http\Router;


$obRouter = new Router();

require __WWW__.'/routes/web.php';
require __WWW__.'/routes/api.php';

$obRouter->run()->sendResponse();